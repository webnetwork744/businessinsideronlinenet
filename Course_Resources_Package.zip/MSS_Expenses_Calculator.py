expenses = {"Rent": 1200, "Food": 400, "Transport": 150}
total = sum(expenses.values())
print("Total Monthly Expenses:", total)
for category, amount in expenses.items():
    print(f"{category}: {amount/total*100:.2f}%")
