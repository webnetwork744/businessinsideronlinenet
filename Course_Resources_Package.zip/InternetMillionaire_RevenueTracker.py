leads = [10, 25, 40, 15]
conversion_rate = 0.2
revenue_per_sale = 50
total_sales = sum([lead * conversion_rate for lead in leads])
total_revenue = total_sales * revenue_per_sale
print("Total Revenue: $", total_revenue)
